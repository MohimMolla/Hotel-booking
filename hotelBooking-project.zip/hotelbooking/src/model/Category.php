<?php
namespace App\model;
class Category{
    public static function  testing(){
        return "testing cat";
    }
}