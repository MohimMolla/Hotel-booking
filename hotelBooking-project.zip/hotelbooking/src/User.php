<?php
namespace App;
class User{
    public function testme(){
        return "testme called<br>";
    }
}